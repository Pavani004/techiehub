<div style="clear:both" class="pnel panel-default footer">
    <div class="footer-1">
        <div class="panel-footer footer-2">Copyright @ AMAN KUMAR E-Commerce Website Project</div>
    </div>

</div>